# SOAR platform

Implementation of the SOAR technical spec v0.9. **Current state: Step 5 (queue-first ingestion, Wazuh source).**

One Go binary (`soar`), one image, role chosen by subcommand. Step 1 delivers the repo layout, the dev stack,
config validation, JSON logging, health endpoints and CI. No business logic yet.

## Quick start (Rocky Linux 10.x)

```bash
sudo ./scripts/rocky10-setup.sh      # once: Docker CE, compose plugin, Go, make, vm.max_map_count
# log out/in so the docker group applies, then:
./scripts/rename-module.sh github.com/<you>/soar     # once: set your real module path
cp deploy/compose/.env.example deploy/compose/.env   # optional
make up                              # builds soar:dev, starts the stack, waits for /readyz
make smoke                           # curl -i localhost:8080/readyz  -> 200 {"checks":{"nats":"ok","opensearch":"ok"},"status":"ok"}
make test                            # unit tests
make test-integration                # needs the stack running
make down                            # stop (keep data) | make clean (delete data)
```

`make help` lists every target. Go on the host is only needed for `make test/lint/build`; images build inside Docker.

## Ports (all bound to 127.0.0.1)

| Service | Port | Notes |
|---|---|---|
| api | 8080 | `/healthz`, `/readyz` (REST arrives in Step 4) |
| ingest | 8081 | receiver arrives in Step 5 |
| processor / collector / orchestrator / worker / scheduler | 8082 / 8083 / 8084 / 8085 / 8086 | health only, inside the compose network |
| OpenSearch | 9200 | security plugin **off** in dev |
| OpenSearch Dashboards | 5601 | |
| NATS | 4222 (client), 8222 (monitor) | JetStream on, `sync_interval: always` |

## Configuration (environment, validated at start, bad config = exit 2)

| Variable | Required | Default |
|---|---|---|
| `SOAR_OS_URLS` | yes | comma-separated http(s) URLs |
| `SOAR_OS_USER` / `SOAR_OS_PASSWORD` | no | |
| `SOAR_NATS_URL` | yes | one or more `nats://` URLs, comma-separated |
| `SOAR_PARTITIONS` | no | 8 (1-256) |
| `SOAR_LOG_LEVEL` | no | info |
| `SOAR_HTTP_ADDR` | no | role default (table above) |
| `SOAR_INDEX_PREFIX` | no | `soar` (lowercase letters, digits, `-`, `_`) |
| `SOAR_OS_STATE_REPLICAS` / `SOAR_OS_TS_REPLICAS` | no | 0 (0-5); set 1 in production |
| `SOAR_RETENTION_FILE` | no | `/etc/soar/retention.yaml` (baked into the image from `config/retention.yaml`) |

Master key, OIDC and blob-store variables from spec §16 are added by the steps that use them (9 and 5).

## Layout

Follows spec §4. Packages that belong to later steps contain only a `doc.go` naming the step that fills them.
Import rule: `domain` imports nothing internal; nothing imports `cmd`.

## Step 1 exit gate

- [ ] `make up` finishes and all containers are healthy (`make ps`)
- [ ] `curl localhost:8080/readyz` returns 200 with `opensearch` and `nats` both `ok`
- [ ] `make test` and `make vet` pass; CI green on GitHub
- [ ] `docker stop soar-nats-1` makes `/readyz` return 503 within seconds; starting it restores 200
- [ ] `docker compose -f deploy/compose/docker-compose.yml run --rm -e SOAR_PARTITIONS=0 api` exits 2 and logs every problem

## Step 2: indices, retention and migrations

`soar migrate` creates, for each of the 22 indices in spec section 5, an index template with `dynamic: strict`
mappings, the first index and its alias (`soar-alerts`, `soar-cases`, ...). Five time-series indices (`alerts`, `raw`,
`steprun`, `timeline`, `audit`) use rollover (30 GB or 1 day) plus an ISM delete policy generated from
`config/retention.yaml`. A ledger index (`soar-migrations`) stores a checksum per index, so repeating the command
changes nothing.

```bash
make migrate         # apply (the stack also runs this automatically before every service starts)
make migrate-check   # verify only; exit 1 on drift
```

Changing retention: edit `config/retention.yaml`, run `make migrate`, check with `make migrate-check`.
Changing a mapping: edit `internal/store/opensearch/schema/entities.go`; additive changes apply in place.
An incompatible change needs a `v2` index and `_reindex`.

### Step 2 exit gate

- [ ] `make migrate` twice: second run reports every index `unchanged`
- [ ] `make migrate-check` exits 0
- [ ] unknown field is rejected: `curl -s -XPUT localhost:9200/soar-workflows/_doc/t -H 'Content-Type: application/json' -d '{"x":1}'` returns `strict_dynamic_mapping_exception`
- [ ] `make test` and `make test-integration` pass

## Step 3: storage layer

All reads and writes of documents go through `internal/store` (interfaces) and
`internal/store/opensearch` (the only OpenSearch code). Services never build OpenSearch requests.

- `store.Repo[T]`: `Get`, `Create`, `Put`, `Save` (optimistic: fails with `ErrVersionConflict` if the
  document changed since it was read), `Update` (read-modify-write, bounded retries, then `ErrConflictExhausted`),
  `Delete`, `List` (filters, ranges, one sort key, cursor pagination).
- `store.BulkWriter`: many writes per request with a result per item (`OK`, `Conflict`, `Retryable`, `Permanent`),
  optional per-item version checks, scripted upserts. `opensearch.GroupWriter` merges concurrent callers into
  shared bulk requests (flush at 1,000 ops or 250 ms) and returns only after OpenSearch acknowledged.
- `internal/store/memory` is an in-process implementation for unit tests. `internal/store/storetest` is the
  behaviour contract; memory and OpenSearch must both pass it.
- Time-series indices (`alerts`, `steprun`, ...) are read through a search and cannot be deleted by ID:
  retention removes them. A just-written time-series document is searchable after the next refresh (up to 5 s).

## Step 4: REST API

`api/openapi.yaml` is the contract (served at `/api/v1/openapi.yaml`). Change it first, then the code.
`go test ./internal/api` fails when a route and the document disagree, when a response breaks its schema, or when
an operation is never exercised.

**No authentication until Step 9.** The API is open; Compose publishes it on 127.0.0.1 only. Do not expose it.

| Area | Endpoints (all under `/api/v1`) | Status |
|---|---|---|
| Workflows | `POST/GET /workflows`, `GET/PUT /workflows/{id}`, `POST /workflows/{id}/versions`, `/publish`, `POST /workflows/validate` | done (structural validation; CEL checks in Step 6) |
| Run / cancel | `POST /workflows/{id}/run`, `POST /executions/{id}/cancel` | 501 until Steps 6-8 |
| Executions | `GET /executions`, `GET /executions/{id}`, `GET /executions/{id}/steps` | done (read side) |
| Alerts | `GET/POST /alerts`, `GET /alerts/{id}` | done (POST is manual entry; ingestion is Step 5) |
| Cases | `POST/GET /cases`, `GET/PATCH /cases/{id}`, tasks, observables, timeline | done (alert linking in Step 11) |
| Observables | `GET /observables`, `GET /observables/{id}` | done |
| Connections | `POST/GET /connections`, `GET/DELETE /connections/{id}` | done (`/test` in Step 13) |
| Sources, filters, mappings, queue, approvals, secrets, admin, connectors, `/stream` | | later steps |

Conventions: errors are `application/problem+json` with `request_id`; lists return `{"items": [...], "next_cursor": "..."}`
(`limit` 1-200); creates accept `Idempotency-Key`; single resources carry an `ETag`, and `If-Match` on `PUT`/`PATCH`/publish
turns the update into a compare-and-set (409 on mismatch).

Try it:

```bash
curl -s -XPOST localhost:8080/api/v1/cases -H 'Content-Type: application/json' \
  -d '{"title":"Phishing campaign","severity":4}' | jq .
curl -s 'localhost:8080/api/v1/cases?status=open' | jq .
curl -s localhost:8080/api/v1/openapi.yaml | head
```

### Steps 3-4 exit gates

- [ ] `make test` passes (includes the contract tests and the shared store suite on the in-memory store)
- [ ] `make test-integration` passes (same store suite on real OpenSearch, bulk, group writer, API on the real stack)
- [ ] the curl commands above work against `make up`

## Step 5: ingestion (queue first)

```
Wazuh --push--> ingest (:8081) --\
                                  +--> NATS EVENTS --> processor --> OpenSearch (alerts, observables, executions)
Wazuh indexer <--poll-- collector -/                      \--> DLQ (poison messages, unmappable records)
```

* **ingest** authenticates, parses, filters, maps, publishes to JetStream and answers `202` only after NATS
  stored the event. It never waits for OpenSearch. A full queue gives `503` + `Retry-After`; a noisy source `429`.
* **collector** polls pull sources on a schedule and moves the cursor only after NATS acknowledged every event.
  A lease in `soar-cursors` makes sure one replica polls a source at a time.
* **processor** takes batches of 256, drops exact duplicates (`soar-seen`), groups repeats into one alert per
  fingerprint and 10-minute window (`occurrence_count`), upserts observables, starts matching workflows, and acks a
  message only after its writes succeeded. Poison messages go to the DLQ.
* Sources, mappings, filter sets and managed lists are data (`/api/v1/sources`, `/mappings`, `/filters`, `/lists`),
  each with a dry-run test endpoint. Mappings and filter sets are versioned and immutable.

### Wazuh quick start

```bash
make up                          # runs migrate (adds two index fields) and seed (installs the Wazuh pack)
curl -s localhost:8080/api/v1/sources | jq '.items[].name'          # wazuh-prod, wazuh-pull
```

**Push** (v1): copy `integrations/wazuh/push/custom-soar*` to the manager and add the `<integration>` block from
`integrations/wazuh/README.md`; `api_key` is `SOAR_SOURCE_TOKEN_WAZUH_PROD` (set it in `deploy/compose/.env`).
Try it without Wazuh:

```bash
curl -s -XPOST localhost:8081/ingest/wazuh-prod -H "Authorization: Bearer $SOAR_SOURCE_TOKEN_WAZUH_PROD" \
  -H 'Content-Type: application/json' -d @integrations/wazuh/testdata/05_sshd_auth_success.json
curl -s 'localhost:8080/api/v1/alerts?source_id=wazuh-prod' | jq '.items[0] | {title,severity,occurrence_count,observables}'
```

**Pull** (v1): create a read-only indexer user, set `SOAR_WAZUH_INDEXER_URL`, `_USER`, `_PASSWORD` (and `_CA_FILE`, or
`_INSECURE=true` for development only) in `.env`, then `make seed && make up`. The collector lists the last two daily
indices, never `wazuh-alerts-*`, re-reads a 60 s overlap and relies on the duplicate guard.

**Tune filtering without a deploy**: `PUT /api/v1/lists/wazuh_noisy_rule_ids {"items":["5501"]}`; check with
`POST /api/v1/filters/test`. Keep the Wazuh Integrator filter coarse (`<level>3</level>`): changing it needs a manager restart.

Other useful calls: `GET /queues/stats` (backlog and consumer lag), `GET /dlq`, `POST /dlq/{id}/replay`,
`POST /mappings/test` (shows the exact failing expression), `GET /sources/{id}/health`.

### Step 5 exit gate

```bash
make test                        # unit tests incl. embedded JetStream, golden Wazuh fixtures, processor, collector
make test-integration            # the real stack, incl. a 3,000-event zero-loss check
make loadtest RATE=1000 DURATION=30m     # the 30-minute peak test; prints PASS/FAIL per gate
make loadtest-burst              # 2,000/s for 60 s, queue must drain within 5 minutes
```

- [ ] zero loss: stored occurrences == accepted events, each event guarded exactly once
- [ ] no 5xx, p99 to `202` below 100 ms (client side)
- [ ] queue drains after the burst (`drained ... after the last send` under 5 minutes)

### Measured: what limits throughput

First run on a Rocky Linux VM with `sync_interval: always`: 2,000/s requested, **1,112/s achieved**, p50 116 ms, p99 202 ms
(workers / throughput = 128 / 1,112 = 115 ms: a serial resource at ~1,100/s), zero loss, queue drained. The cause is NATS
syncing to disk on every write: each event costs two fsyncs (publish, and the processor's acknowledgement, which deletes
it from the work queue). An isolated measurement on a faster disk showed the same effect: publish 65,000/s without per-write
fsync versus 4,800/s with it, p50 1.3 ms versus 26 ms.

```bash
make nats-relaxed                        # fsync every 200 ms (deploy/nats/nats-relaxed.conf), recreates the nats container
make loadtest-burst                      # compare with the first run
make nats-always                         # back to fsync on every write
```

Trade-off to decide on purpose: with batched fsync an event acknowledged less than 200 ms before a power loss, kernel panic or
VM crash can be lost; restarting NATS or its container loses nothing. Production runs a 3-node cluster with replicas 3 (a message
is acknowledged only after a quorum has it), which is the real protection. If you need per-write fsync on one node, use a faster
disk (NVMe or a controller with a battery-backed cache) and keep the lower throughput until then.

After NATS is no longer the limit the next one is OpenSearch/processor: watch `GET /api/v1/queues/stats` during a run (EVENTS
`pending` should stay small), and raise `SOAR_PROCESSOR_WORKERS` (try 4) in `deploy/compose/.env`, then `make up`.
`make loadtest` prints a hint when the target rate is not reached.

Notes: the six Wazuh fixtures were built from the spec's field descriptions, replace them with real samples (see
`integrations/wazuh/README.md`). `occurrence_count` can overshoot by the events of one batch after a processor crash
between its two writes; events are never lost and never duplicated as documents. Replay of stored raw events
(`/sources/{id}/replay`, `/filters/simulate`) needs full raw capture and comes with the DLQ tooling in Step 8.
