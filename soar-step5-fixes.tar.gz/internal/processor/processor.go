// Package processor consumes events from NATS and writes them to OpenSearch (spec 9.9):
// exact-duplicate guard, alert upserts that group repeats, observables, workflow
// triggers. A message is acknowledged only after its writes succeeded.
package processor

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"hash/fnv"
	"log/slog"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"github.com/nats-io/nats.go/jetstream"

	"github.com/yourorg/soar/internal/domain"
	"github.com/yourorg/soar/internal/store"
)

// DLQ is the part of the queue client the processor needs.
type DLQ interface {
	SendToDLQ(ctx context.Context, origin, reason, subject string, data []byte, id string, extra map[string]string) error
}

// Config tunes the processor.
type Config struct {
	Batch      int           // messages per fetch (spec: 256)
	FetchWait  time.Duration // how long a fetch waits for a full batch
	Workers    int           // concurrent fetch loops
	Partitions int           // orchestrator partitions (SOAR_PARTITIONS)
	NakDelay   time.Duration // delay before a transiently failed message is redelivered
	LocalRetry int           // retries of retryable bulk items before giving up and nak-ing
}

func (c *Config) defaults() {
	if c.Batch <= 0 {
		c.Batch = 256
	}
	if c.FetchWait <= 0 {
		c.FetchWait = 500 * time.Millisecond
	}
	if c.Workers <= 0 {
		c.Workers = 2
	}
	if c.Partitions <= 0 {
		c.Partitions = 8
	}
	if c.NakDelay <= 0 {
		c.NakDelay = 2 * time.Second
	}
	if c.LocalRetry <= 0 {
		c.LocalRetry = 3
	}
}

// Counters are exported for health output and tests.
type Counters struct {
	Processed, Duplicates, DeadLettered, Retried, Executions atomic.Int64
}

// Processor turns queued events into alerts, observables and executions.
type Processor struct {
	Cons     jetstream.Consumer
	Bulk     store.BulkWriter
	St       *store.Store
	DLQ      DLQ
	Triggers *TriggerIndex
	Log      *slog.Logger
	Cfg      Config
	Stats    Counters
}

type item struct {
	msg      jetstream.Msg
	ev       domain.Event
	alertID  string
	seenID   string
	retryErr error // transient failure: nak
	dup      bool  // exact duplicate: nothing to write, just acknowledge
	done     bool  // already acked / termed / nak-ed
}

// Run fetches and processes batches until ctx ends.
func (p *Processor) Run(ctx context.Context) error {
	p.Cfg.defaults()
	var wg sync.WaitGroup
	for i := 0; i < p.Cfg.Workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for ctx.Err() == nil {
				batch, err := p.Cons.Fetch(p.Cfg.Batch, jetstream.FetchMaxWait(p.Cfg.FetchWait))
				if err != nil {
					if ctx.Err() == nil {
						p.Log.Warn("fetch failed", "error", err.Error())
						sleep(ctx, time.Second)
					}
					continue
				}
				var msgs []jetstream.Msg
				for m := range batch.Messages() {
					msgs = append(msgs, m)
				}
				if len(msgs) > 0 {
					p.HandleBatch(ctx, msgs)
				}
			}
		}()
	}
	wg.Wait()
	return nil
}

func sleep(ctx context.Context, d time.Duration) {
	select {
	case <-ctx.Done():
	case <-time.After(d):
	}
}

func (p *Processor) deadLetter(ctx context.Context, it *item, reason string) {
	if it.done {
		return
	}
	id := "proc-" + it.msg.Subject()
	if md, err := it.msg.Metadata(); err == nil {
		id += "-" + strconv.FormatUint(md.Sequence.Stream, 10)
	}
	if err := p.DLQ.SendToDLQ(ctx, "events", reason, it.msg.Subject(), it.msg.Data(), id, nil); err != nil {
		// Without a durable copy we must not discard the message: let it be redelivered.
		p.Log.Error("could not dead-letter; message will be redelivered", "reason", reason, "error", err.Error())
		_ = it.msg.NakWithDelay(p.Cfg.NakDelay)
		it.done = true
		return
	}
	_ = it.msg.Term() // a terminated work-queue message is removed
	it.done = true
	p.Stats.DeadLettered.Add(1)
}

func (p *Processor) nak(it *item) {
	if it.done {
		return
	}
	_ = it.msg.NakWithDelay(p.Cfg.NakDelay)
	it.done = true
	p.Stats.Retried.Add(1)
}

func (p *Processor) ack(ctx context.Context, it *item) {
	if it.done {
		return
	}
	actx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	if err := it.msg.DoubleAck(actx); err != nil {
		p.Log.Warn("ack was not confirmed; the message may be redelivered (writes are idempotent)", "error", err.Error())
	}
	it.done = true
}

// bulkWithRetry writes ops and retries items that failed transiently (429, 5xx).
// It returns the final result for every op. A whole-request error is returned as err.
func (p *Processor) bulkWithRetry(ctx context.Context, ops []store.BulkOp) ([]store.BulkResult, error) {
	if len(ops) == 0 {
		return nil, nil
	}
	final := make([]store.BulkResult, len(ops))
	pending := make([]int, len(ops))
	for i := range pending {
		pending[i] = i
	}
	for attempt := 0; len(pending) > 0; attempt++ {
		batch := make([]store.BulkOp, len(pending))
		for i, idx := range pending {
			batch[i] = ops[idx]
		}
		res, err := p.Bulk.Write(ctx, batch)
		if err != nil {
			return nil, err
		}
		if len(res) != len(batch) {
			return nil, fmt.Errorf("bulk returned %d results for %d operations", len(res), len(batch))
		}
		var next []int
		for i, idx := range pending {
			final[idx] = res[i]
			if res[i].Retryable() && attempt < p.Cfg.LocalRetry {
				next = append(next, idx)
			}
		}
		pending = next
		if len(pending) > 0 {
			sleep(ctx, time.Duration(200<<attempt)*time.Millisecond)
		}
	}
	return final, nil
}

func partition(id string, n int) int {
	h := fnv.New32a()
	_, _ = h.Write([]byte(id))
	return int(h.Sum32() % uint32(n))
}

// AlertID is deterministic in (fingerprint, window bucket): repeats of the same alert
// inside the window upsert one document, and a redelivered event hits the same document.
func AlertID(fingerprint string, receivedAt time.Time, windowSec int) string {
	if windowSec <= 0 {
		windowSec = 600
	}
	return domain.DeterministicID(domain.PrefixAlert, fingerprint, receivedAt.Unix()/int64(windowSec))
}

const alertScript = `ctx._source.occurrence_count += 1;
ctx._source.last_seen = params.t;
ctx._source.updated_at = params.now;
if (params.sev > ctx._source.severity) { ctx._source.severity = params.sev; }`

const touchScript = `ctx._source.last_seen = params.t; ctx._source.updated_at = params.now;`

func stamp(id string, now time.Time) domain.Meta {
	return domain.Meta{ID: id, CreatedAt: now, UpdatedAt: now, SchemaVersion: domain.SchemaVersion}
}

// HandleBatch processes one fetched batch. Every message ends acknowledged, dead-lettered
// or scheduled for redelivery; none is left hanging.
func (p *Processor) HandleBatch(ctx context.Context, msgs []jetstream.Msg) {
	p.Cfg.defaults()
	now := time.Now().UTC()
	names := p.St.Names
	items := make([]*item, 0, len(msgs))

	// 1. decode; undecodable messages are poison and go straight to the DLQ
	for _, m := range msgs {
		it := &item{msg: m}
		if err := json.Unmarshal(m.Data(), &it.ev); err != nil || it.ev.Alert.Title == "" || it.ev.Alert.Fingerprint == "" {
			reason := "invalid event"
			if err != nil {
				reason = "invalid event: " + err.Error()
			}
			p.deadLetter(ctx, it, reason)
			continue
		}
		it.alertID = AlertID(it.ev.Alert.Fingerprint, it.ev.ReceivedAt, it.ev.DedupWindowSec)
		items = append(items, it)
	}

	// 2. exact-duplicate guard: create a soar-seen key per external id; a conflict means
	// the same event already arrived (push and pull overlap, or a sender retry)
	var seenOps []store.BulkOp
	var seenFor []*item
	for _, it := range items {
		if it.ev.Alert.ExternalID == "" {
			continue
		}
		key := it.ev.Alert.System + ":" + it.ev.Alert.ExternalID
		it.seenID = domain.DeterministicID("see", key)
		seenOps = append(seenOps, store.BulkOp{Action: store.BulkCreate, Index: names.Index("seen"), ID: it.seenID,
			Doc: domain.Seen{Meta: stamp(it.seenID, now), Key: key, EventID: it.ev.EventID, FirstSeen: now}})
		seenFor = append(seenFor, it)
	}
	if res, err := p.bulkWithRetry(ctx, seenOps); err != nil {
		p.Log.Warn("duplicate guard failed; retrying the whole batch later", "error", err.Error())
		for _, it := range items {
			p.nak(it)
		}
		return
	} else {
		for i, it := range seenFor {
			r := res[i]
			switch {
			case r.OK():
			case r.Conflict():
				own, err := p.isOwnRetry(ctx, it)
				switch {
				case err != nil:
					it.retryErr = err // cannot tell a retry from a duplicate: never guess, never lose the event
				case own:
					// our own earlier attempt created the key; carry on
				default:
					p.Stats.Duplicates.Add(1)
					it.dup = true // acknowledged with the rest of the batch
				}
			case r.Retryable():
				it.retryErr = r.Err
			default:
				p.deadLetter(ctx, it, "duplicate guard rejected the event: "+errText(r.Err))
			}
		}
	}

	// 3. alerts, observables, executions in one bulk
	type ref struct {
		it   *item
		kind string
	}
	var ops []store.BulkOp
	var refs []ref
	obsSeen := map[string]bool{}
	for _, it := range items {
		if it.done || it.dup || it.retryErr != nil {
			continue
		}
		a := it.ev.Alert
		t := it.ev.ReceivedAt
		if a.LastSeen != nil {
			t = *a.LastSeen
		}
		doc := a
		doc.Meta = stamp(it.alertID, now)
		doc.ReceivedAt = it.ev.ReceivedAt
		doc.LastSeen = &t
		doc.OccurrenceCount = 1
		ops = append(ops, store.BulkOp{Action: store.BulkUpdate, Index: names.Index("alerts"), ID: it.alertID, Retries: 5, Body: map[string]any{
			"script": map[string]any{"lang": "painless", "source": alertScript,
				"params": map[string]any{"t": t.Format(time.RFC3339Nano), "now": now.Format(time.RFC3339Nano), "sev": a.Severity}},
			"upsert": doc,
		}})
		refs = append(refs, ref{it, "alert"})

		for _, o := range a.Observables {
			id := domain.ObservableID(o.Type, o.Value)
			if obsSeen[id] {
				continue
			}
			obsSeen[id] = true
			od := domain.ObservableDoc{Meta: stamp(id, now), Type: o.Type, Value: o.Value, FirstSeen: t, LastSeen: t}
			ops = append(ops, store.BulkOp{Action: store.BulkUpdate, Index: names.Index("observables"), ID: id, Retries: 5, Body: map[string]any{
				"script": map[string]any{"lang": "painless", "source": touchScript,
					"params": map[string]any{"t": t.Format(time.RFC3339Nano), "now": now.Format(time.RFC3339Nano)}},
				"upsert": od,
			}})
			refs = append(refs, ref{it, "observable"})
		}

		if p.Triggers != nil {
			for _, m := range p.Triggers.For(it.ev) {
				id := domain.DeterministicID(domain.PrefixExecution, it.alertID, m.WorkflowName)
				ex := domain.Execution{Meta: stamp(id, now), WorkflowID: m.WorkflowID, WorkflowVersion: m.Version, Status: "queued",
					Trigger: domain.ExecutionTrigger{Type: "alert", Kind: a.Kind, AlertID: it.alertID, EventID: it.ev.EventID}, Partition: partition(id, p.Cfg.Partitions)}
				ops = append(ops, store.BulkOp{Action: store.BulkCreate, Index: names.Index("executions"), ID: id, Doc: ex})
				refs = append(refs, ref{it, "execution"})
			}
		}
	}
	res, err := p.bulkWithRetry(ctx, ops)
	if err != nil {
		p.Log.Warn("write failed; retrying the batch later", "error", err.Error())
		for _, it := range items {
			p.nak(it)
		}
		return
	}
	for i, r := range res {
		it := refs[i].it
		switch {
		case r.OK():
			if refs[i].kind == "execution" {
				p.Stats.Executions.Add(1)
			}
		case refs[i].kind == "execution" && r.Conflict():
			// this alert already started that workflow: exactly what idempotency is for
		case r.Retryable() || r.Conflict():
			if it.retryErr == nil {
				it.retryErr = r.Err
			}
		default:
			p.deadLetter(ctx, it, fmt.Sprintf("%s write rejected: %s", refs[i].kind, errText(r.Err)))
		}
	}

	// 4. settle every message. Acknowledgements are confirmed round trips (DoubleAck) and
	// each one is a write in the work-queue stream, so they run concurrently.
	var toAck []*item
	for _, it := range items {
		switch {
		case it.done:
		case it.retryErr != nil:
			p.nak(it)
		default:
			toAck = append(toAck, it)
		}
	}
	p.ackAll(ctx, toAck)
}

const ackParallelism = 32

func (p *Processor) ackAll(ctx context.Context, items []*item) {
	sem := make(chan struct{}, ackParallelism)
	var wg sync.WaitGroup
	for _, it := range items {
		sem <- struct{}{}
		wg.Add(1)
		go func(it *item) {
			defer func() { <-sem; wg.Done() }()
			p.ack(ctx, it)
			if !it.dup {
				p.Stats.Processed.Add(1)
			}
		}(it)
	}
	wg.Wait()
}

// isOwnRetry tells a redelivery of an event we started processing earlier from a true
// duplicate: on redelivery the seen key may carry this very event id.
func (p *Processor) isOwnRetry(ctx context.Context, it *item) (bool, error) {
	md, err := it.msg.Metadata()
	if err != nil || md.NumDelivered < 2 {
		return false, nil // a first delivery that conflicts is a genuine duplicate
	}
	s, _, err := p.St.Seen.Get(ctx, it.seenID)
	if errors.Is(err, store.ErrNotFound) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return s.EventID == it.ev.EventID, nil
}

func errText(e *store.BulkError) string {
	if e == nil {
		return "unknown error"
	}
	return e.Error()
}
